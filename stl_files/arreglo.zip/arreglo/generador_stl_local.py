import json
import os
import trimesh
from shapely.geometry import Polygon

def generar_stl_desde_json(json_path, altura, output_stl):
    with open(json_path, 'r') as file:
        data = json.load(file)

    vector_paths = data.get("vector_paths", [])
    mallas = []

    for ruta in vector_paths:
        if len(ruta) < 3:
            continue
        try:
            pol = Polygon(ruta)
            if not pol.is_valid or pol.is_empty:
                continue
            malla = trimesh.creation.extrude_polygon(pol, height=altura)
            mallas.append(malla)
        except Exception as e:
            print(f"❗ Error con ruta: {ruta} → {e}")

    if not mallas:
        raise ValueError("No se pudo generar ninguna malla 3D válida a partir de los contornos.")

    malla_final = trimesh.util.concatenate(mallas)
    malla_final.export(output_stl)
    return os.path.abspath(output_stl)
