# 🚨 Políticas de Manejo de Errores y Recuperación - Asistente UpToBe

---

## 🧠 Filosofía General

El asistente UpToBe debe gestionar todos los errores de forma controlada, clara y transparente, siempre proporcionando al usuario:
- Mensajes de error explícitos.
- Opciones claras para corregir o reiniciar el proceso.
- Guía inmediata para minimizar la interrupción del flujo.

---

## ⚙️ Tipos de errores previstos

### 1. Error de Preprocesamiento
**Causa posible:**  
- Imagen corrupta.
- Formato no compatible.
- Imagen ilegible.

**Acción:**  
- Notificar al usuario: `"Error en el preprocesamiento de la imagen. Por favor, verifique que el archivo esté en formato permitido y que no esté dañado."`
- Ofrecer opción de reintentar cargando una nueva imagen.

---

### 2. Error en Limpieza de Imagen
**Causa posible:**  
- Imagen demasiado degradada.
- No se encuentran contornos válidos.

**Acción:**  
- Notificar al usuario: `"Error durante la limpieza de la imagen. No se han detectado contornos útiles."`
- Sugerir:
  - Reintentar con otra imagen.
  - Aumentar el contraste manualmente antes de subir la imagen.

---

### 3. Error en Vectorización
**Causa posible:**  
- Contornos mal formados.
- Imagen no binaria correctamente preprocesada.

**Acción:**  
- Notificar al usuario: `"No se pudieron vectorizar los contornos correctamente. Intente revisar la imagen procesada o limpiar el archivo inicial."`
- Proponer volver a la fase de limpieza.

---

### 4. Error en Generación de STL
**Causa posible:**  
- Polígonos degenerados (muy pequeños o inválidos).
- Fallo interno de extrusión en el servidor remoto.
- Error de comunicación o error HTTP en la respuesta del servidor.

**Acción:**  
- Notificar al usuario: `"Error al generar el archivo STL. Puede deberse a contornos defectuosos o a un fallo de procesamiento externo."`
Reintentar inmediatamente sin ofrecer ningún mensaje al usuario :
- Revisar contornos vectorizados.
- Reiniciar el flujo desde la fase de vectorización.


---

## 🧩 Procedimiento estándar de recuperación

Ante cualquier error:
1. Mostrar un mensaje claro y breve explicando la naturaleza del problema.
2. Entregar detalles técnicos solo si es necesario (no saturar al usuario).
3. Sugerir siempre al menos:
   - Reintentar la última fase.
   - Volver al paso anterior.
   - Subir un nuevo archivo de entrada.
4. En caso de error en generación de STL, verificar el código de respuesta HTTP recibido.

---

## 🔄 Protocolo de Reinicio de Flujo

Si el usuario lo solicita, o si el error es crítico:
- El asistente debe ofrecer la opción `"¿Deseas iniciar el proceso desde cero?"`.
- Esto limpia las variables internas y vuelve al primer paso (subida de imagen).

---

## 📂 Registro de errores

Si es posible, cada error significativo debe:
- Registrarse internamente con timestamp.
- Adjuntar contexto mínimo (tipo de fallo, fase en la que ocurrió).
- Este registro ayuda en depuración futura.

---

## 🔥 Mensaje Final de Error Grave

Si ocurre un error irrecuperable:

```plaintext
"Se ha producido un error inesperado. 
Por favor, reinicia el flujo de trabajo o contacta con soporte en soporte@uptobe.io"
