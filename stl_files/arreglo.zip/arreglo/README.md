# 🧠 Asistente de Conversión 2D a STL - UpToBe

Este proyecto convierte imágenes 2D en modelos 3D (archivos STL) listos para impresión 3D o mecanizado CNC, combinando procesamiento de imagen local y generación remota de STL.

---

## 🚀 Funcionalidades

- Preprocesamiento de imágenes local: binarización en blanco y negro.
- Limpieza profunda local mediante detección de contornos jerárquicos.
- Vectorización de contornos local.
- Generación de archivos STL mediante llamada externa a un backend especializado.

---

## 📁 Estructura del Proyecto

- main.py
- Dockerfile
- requirements.txt
- Procfile
- .gitignore
- .gitattributes

---

## ⚙️ Requisitos

```bash
pip install -r requirements.txt
No es necesario instalar triangle.


🧪 Cómo ejecutar localmente

git clone https://github.com/tu_usuario/Asistente-de-conversion-STL.git
cd Asistente-de-conversion-STL
python3 -m venv env && source env/bin/activate
pip install -r requirements.txt
python main.py

Servidor:
http://localhost:8000

✨ Endpoints disponibles

Endpoint | Funcionalidad
POST /procesar-imagen | Preprocesar imagen en binario
POST /limpiar | Limpiar imagen detectando contornos
POST /vectorizar-contornos | Vectorizar contornos
POST /generar-stl | Llamada al backend para generar STL


📌 Notas técnicas

Todo procesamiento de imagen es local.
STL se genera mediante backend externo.

---

### `.gitignore`
```plaintext
__pycache__/
*.pyc
*.pyo
*.pyd
.env
.venv
*.env
*.venv
uploads/
