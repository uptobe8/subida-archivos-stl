# 📚 Glosario Técnico - Asistente UpToBe

---

## 🖼️ Imagen Binaria

**Definición:**  
Una imagen compuesta únicamente por dos colores: blanco y negro.  
Se utiliza para separar claramente el fondo del objeto principal en los procesos de vectorización y modelado 3D.

---

## 🎯 Preprocesamiento

**Definición:**  
Fase inicial de tratamiento de imagen donde se convierte la imagen original en escala de grises y posteriormente a binario mediante umbral adaptativo.

**Objetivo:**  
Aumentar el contraste y facilitar la limpieza y vectorización posterior.

---

## 🧹 Limpieza Profunda

**Definición:**  
Proceso de eliminación de ruido visual, manchas y fondos no deseados mediante técnicas de detección de contornos locales (`cv2.findContours` en modo `RETR_TREE`).

**Objetivo:**  
Mantener únicamente los trazos relevantes del objeto principal de la imagen.

---

## 📏 Escala y Proporción

**Definición:**  
Tamaño relativo y forma original de la imagen.  
El asistente **no debe** modificar ni redimensionar las proporciones originales durante el procesamiento.

---

## 🖋️ Contornos

**Definición:**  
Líneas cerradas que delimitan objetos o formas dentro de una imagen.  
Detectados mediante algoritmos de visión por computadora.

**Importante:**  
El asistente debe detectar tanto contornos externos como internos para preservar la estructura completa de la imagen.

---

## 🗺️ Jerarquía de Contornos (`RETR_TREE`)

**Definición:**  
Método que permite capturar la relación entre contornos externos e internos en una imagen.

**Ejemplo:**  
Una letra “O” tiene:
- Un contorno exterior (el círculo principal).
- Un contorno interior (el hueco).

Ambos deben preservarse para un STL correcto.

---

## 📐 Vectorización

**Definición:**  
Conversión de contornos de una imagen binaria en datos vectoriales (coordenadas de puntos).

**Utilidad:**  
Permite representar formas de manera precisa para su posterior extrusión a modelos 3D.

---

## 🧱 Extrusión

**Definición:**  
Proceso de dar volumen a un contorno plano (2D) para convertirlo en un objeto tridimensional (3D).

**Método utilizado:**  
`trimesh.creation.extrude_polygon(poligono, altura)`

---

## 📦 STL (Stereolithography)

**Definición:**  
Formato estándar de archivo para modelos 3D.  
Utilizado comúnmente en impresión 3D y mecanizado CNC.

**Características del STL generado:**
- Archivo real y descargable.
- Debe ser una malla cerrada, sin huecos.
- Contiene vértices (puntos) y caras (triángulos).

---

## ⚙️ Procesamiento Local

**Definición:**  
Operaciones de preprocesamiento de imagen, limpieza y vectorización que se realizan dentro del servidor del asistente, sin conexión a servicios externos.

**Nota:**  
La generación final del archivo STL se realiza mediante una llamada segura a un servidor remoto especializado.

---

## ❌ Segment Anything (SAM)

**Definición (anterior):**  
Modelo de IA para segmentación automática de objetos en imágenes.

**Estado actual en el asistente:**  
**NO utilizado.**  
La limpieza se realiza exclusivamente de forma local mediante OpenCV y contornos.

---

## 🔒 Política de no modificación

**Definición:**  
Norma interna que prohíbe:

- Cambiar la escala de la imagen.
- Recortar márgenes.
- Recentrar elementos automáticamente.
- Redimensionar el tamaño de los objetos.

El asistente debe respetar la resolución y proporción exacta del archivo de entrada.

---

## 🛠️ Herramientas utilizadas

- **OpenCV**: Procesamiento de imágenes (binarización, limpieza, contornos).
- **Shapely**: Creación de polígonos vectoriales.
- **Trimesh**: Extrusión y generación de modelos STL.

---
