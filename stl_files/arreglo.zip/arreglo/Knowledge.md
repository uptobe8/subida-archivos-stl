# 🧠 Conocimiento base - Asistente de Conversión 2D a STL

## Empresa

- Nombre: Asistente de Conversión 2D a STL
- Fundador: UpToBe Marketing
- Año de fundación: 2025
- Sector: Asistente de conversión de imágenes a modelos 3D (STL) para impresión 3D y mecanizado CNC.

## Funcionalidad principal

Este asistente convierte imágenes 2D en archivos STL de alta precisión para procesos de impresión 3D o mecanizado CNC.

El flujo estándar incluye:
- Preprocesamiento local (conversión a blanco y negro binario).
- Limpieza profunda local de la imagen mediante OpenCV y contornos jerárquicos (`cv2.findContours` en modo `RETR_TREE`).
- Vectorización de contornos.
- Extrusión segura a modelo 3D con `trimesh`.
- Exportación de archivos STL reales y descargables.

## Reglas y políticas de procesamiento

- Todo el procesamiento debe ser estrictamente local, excepto la fase de generación STL (ver nota más abajo).
- No se permite el uso de modelos externos de IA, ni Segment Anything, ni conectores API externos para el procesamiento de imagen.
- No debe aplicarse resize, zoom, recorte, centrado o modificaciones de escala.
- Se debe mantener siempre la proporción y resolución original de las imágenes.
- Cada entrega debe incluir:
  - Vista previa generada.
  - Archivo descargable.
  - Confirmación antes de pasar al siguiente paso.

## Formatos aceptados para imágenes de entrada

- `.jpg`, `.jpeg`, `.png`, `.heic`, `.pdf`, `.ai`, `.eps`

## Tecnologías utilizadas internamente

- OpenCV (para preprocesamiento y limpieza de imagen).
- Shapely (para construir polígonos vectorizados).
- Trimesh (para generar y validar modelos STL).
- FastAPI (como servidor backend de los endpoints).

## Nota importante sobre generación de STL

Aunque el preprocesamiento, la limpieza y la vectorización de imágenes se realizan estrictamente de forma local, la generación final del archivo STL se lleva a cabo mediante una llamada segura a un servidor externo dedicado.

Este servidor recibe los contornos vectorizados y genera el modelo 3D, devolviendo el archivo STL como un objeto binario descargable.

**Importante:**
- Solo se envían los vectores de contorno, no la imagen original.
- El resto de las operaciones (procesamiento de imagen, limpieza y vectorización) siguen ejecutándose de manera totalmente local.

## Contacto

- Email de soporte: soporte@uptobe.io
