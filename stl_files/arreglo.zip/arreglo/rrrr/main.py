from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
import uvicorn
import cv2
import numpy as np
import tempfile
from typing import List
import shapely.geometry
import trimesh
import os

app = FastAPI()

# ---------------------------
# Endpoint: Preprocesar imagen
# ---------------------------
@app.post("/procesar-imagen")
async def procesar_imagen(imagen: UploadFile = File(...)):
    contents = await imagen.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    adaptive_thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        15, 10
    )

    if np.sum(adaptive_thresh == 0) > np.sum(adaptive_thresh == 255):
        adaptive_thresh = cv2.bitwise_not(adaptive_thresh)

    _, temp_path = tempfile.mkstemp(suffix=".png")
    cv2.imwrite(temp_path, adaptive_thresh)

    return StreamingResponse(open(temp_path, "rb"), media_type="image/png")

# ---------------------------
# Endpoint: Limpiar imagen
# ---------------------------
@app.post("/limpiar")
async def limpiar(imagen: UploadFile = File(...)):
    contents = await imagen.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)

    contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    cleaned_img = np.ones_like(img) * 255  # fondo blanco

    min_area = 100

    for cnt in contours:
        if cv2.contourArea(cnt) > min_area:
            cv2.drawContours(cleaned_img, [cnt], -1, (0,), thickness=2)

    kernel = np.ones((3, 3), np.uint8)
    closed_img = cv2.morphologyEx(cleaned_img, cv2.MORPH_CLOSE, kernel, iterations=2)
    dilated_img = cv2.dilate(closed_img, kernel, iterations=1)

    _, temp_path = tempfile.mkstemp(suffix=".png")
    cv2.imwrite(temp_path, dilated_img)

    return StreamingResponse(open(temp_path, "rb"), media_type="image/png")

# ---------------------------
# Endpoint: Vectorizar contornos
# ---------------------------
@app.post("/vectorizar-contornos")
async def vectorizar_contornos(ruta_imagen_binaria: str):
    img = cv2.imread(ruta_imagen_binaria, cv2.IMREAD_GRAYSCALE)

    contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    vector_paths = []
    for contour in contours:
        contour = contour.squeeze()
        if len(contour.shape) == 1:
            contour = np.expand_dims(contour, axis=0)
        path = contour.tolist()
        if isinstance(path[0], list):
            vector_paths.append(path)

    return {"vector_paths": vector_paths}

# ---------------------------
# Endpoint: Generar STL localmente
# ---------------------------
@app.post("/generar-stl")
async def generar_stl(vector_paths: List[List[List[float]]], altura_extrusion: float = 5.0):
    import requests

    try:
        payload = {
            "vector_paths": vector_paths,
            "altura_extrusion": altura_extrusion
        }
        response = requests.post("http://localhost:8080/generar-stl-local", json=payload)
        if response.status_code == 200:
            result = response.json()
            stl_path = result["stl_path"]
            return StreamingResponse(open(stl_path, "rb"), media_type="application/octet-stream")
        else:
            raise HTTPException(status_code=response.status_code, detail="Error desde el motor STL local.")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        
# ---------------------------
# Ejecutar servidor
# ---------------------------
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
