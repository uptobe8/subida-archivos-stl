# 🧠 Asistente de Conversión 2D a STL

Este proyecto convierte imágenes 2D en archivos STL listos para impresión 3D o mecanizado CNC.  
Las fases 1 a 3 se hacen localmente. La fase 4 (generación STL) se hace mediante un backend remoto.

## Flujo
1. Preprocesamiento (imagen binaria)
2. Limpieza (contornos)
3. Vectorización
4. Extrusión STL (vía API remota)

## Uso
Usa FastAPI con endpoints:
- `/procesar-imagen`
- `/limpiar`
- `/vectorizar-contornos`
- `/generar-stl` (envía datos al servidor STL)
