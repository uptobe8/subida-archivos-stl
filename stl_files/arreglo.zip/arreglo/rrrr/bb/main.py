from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import StreamingResponse
import cv2
import numpy as np
import shutil
import os
import requests
from typing import List

app = FastAPI()

@app.post("/procesar-imagen")
async def procesar_imagen(imagen: UploadFile = File(...)):
    contents = await imagen.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    adaptive_thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        15, 10
    )
    if np.sum(adaptive_thresh == 0) > np.sum(adaptive_thresh == 255):
        adaptive_thresh = cv2.bitwise_not(adaptive_thresh)

    out_path = "/mnt/data/imagen_binaria.png"
    cv2.imwrite(out_path, adaptive_thresh)
    return StreamingResponse(open(out_path, "rb"), media_type="image/png")

@app.post("/limpiar")
async def limpiar_imagen(imagen: UploadFile = File(...)):
    contents = await imagen.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)

    contours, _ = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cleaned = np.ones_like(img) * 255
    cv2.drawContours(cleaned, contours, -1, (0), 1)

    out_path = "/mnt/data/imagen_limpia.png"
    cv2.imwrite(out_path, cleaned)
    return StreamingResponse(open(out_path, "rb"), media_type="image/png")

@app.post("/vectorizar-contornos")
async def vectorizar(ruta_imagen_binaria: str):
    img = cv2.imread(ruta_imagen_binaria, cv2.IMREAD_GRAYSCALE)
    contours, _ = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    vector_paths = []
    for contour in contours:
        if len(contour) >= 3:
            path = [[int(p[0][0]), int(p[0][1])] for p in contour]
            vector_paths.append(path)

    if not vector_paths:
        raise HTTPException(status_code=422, detail="No se encontraron contornos válidos.")

    return {"vector_paths": vector_paths}

@app.post("/generar-stl")
async def generar_stl(vector_paths: List[List[List[float]]], altura_extrusion: float = 5.0):
    try:
        response = requests.post(
            "https://asistente-de-conversion-stl.onrender.com/generar-stl",
            json={"vector_paths": vector_paths, "altura_extrusion": altura_extrusion}
        )
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Fallo en el servidor de STL")

        stl_path = "/mnt/data/modelo.stl"
        with open(stl_path, "wb") as f:
            f.write(response.content)

        return StreamingResponse(open(stl_path, "rb"), media_type="application/octet-stream")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
