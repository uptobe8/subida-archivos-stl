# Asistente de Conversión 2D a STL (versión limpia)

Este repositorio contiene el backend de FastAPI que realiza las fases 1 a 3 (procesamiento, limpieza y vectorización) de una imagen.

La generación STL se realiza remotamente, desde el endpoint:  
https://asistente-de-conversion-stl.onrender.com/generar-stl

No necesitas instalar ninguna librería 3D localmente.

Incluye:
- `/procesar-imagen`
- `/limpiar`
- `/vectorizar-contornos`
- `/generar-stl` (envía a servidor remoto y entrega STL como archivo)
