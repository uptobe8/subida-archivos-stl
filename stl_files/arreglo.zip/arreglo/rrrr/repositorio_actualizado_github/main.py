from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
import cv2
import numpy as np
import os
import shutil
import uuid
import requests
import json

app = FastAPI()

@app.post("/procesar-imagen")
async def procesar_imagen(imagen: UploadFile = File(...)):
    contenido = await imagen.read()
    nombre_archivo = f"/mnt/data/{uuid.uuid4()}.png"
    with open(nombre_archivo, "wb") as f:
        f.write(contenido)

    original = cv2.imread(nombre_archivo)
    gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
    adaptive_thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        15, 10
    )
    if np.sum(adaptive_thresh == 0) > np.sum(adaptive_thresh == 255):
        adaptive_thresh = cv2.bitwise_not(adaptive_thresh)

    salida_path = nombre_archivo.replace(".png", "_binaria.png")
    cv2.imwrite(salida_path, adaptive_thresh)
    return FileResponse(salida_path, media_type="image/png")

@app.post("/limpiar")
async def limpiar_imagen(imagen: UploadFile = File(...)):
    contenido = await imagen.read()
    nombre_archivo = f"/mnt/data/{uuid.uuid4()}.png"
    with open(nombre_archivo, "wb") as f:
        f.write(contenido)

    imagen = cv2.imread(nombre_archivo, cv2.IMREAD_GRAYSCALE)
    contornos, jerarquia = cv2.findContours(imagen, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    salida = np.ones_like(imagen) * 255
    cv2.drawContours(salida, contornos, -1, (0,), 1)
    salida_path = nombre_archivo.replace(".png", "_limpia.png")
    cv2.imwrite(salida_path, salida)
    return FileResponse(salida_path, media_type="image/png")

@app.post("/vectorizar-contornos")
async def vectorizar_contornos(payload: dict):
    ruta_imagen_binaria = payload.get("ruta_imagen_binaria")
    if not ruta_imagen_binaria or not os.path.exists(ruta_imagen_binaria):
        raise HTTPException(status_code=400, detail="Ruta inválida o archivo no encontrado.")

    imagen = cv2.imread(ruta_imagen_binaria, cv2.IMREAD_GRAYSCALE)
    contornos, jerarquia = cv2.findContours(imagen, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    vector_paths = []
    for cnt in contornos:
        if len(cnt) >= 3:
            path = [[int(p[0][0]), int(p[0][1])] for p in cnt]
            vector_paths.append(path)

    json_path = ruta_imagen_binaria.replace(".png", ".json")
    with open(json_path, "w") as f:
        json.dump({"vector_paths": vector_paths}, f)

    return {"vector_paths": vector_paths}

@app.post("/generar-stl")
async def generar_stl(data: dict):
    try:
        response = requests.post(
            "https://asistente-de-conversion-stl.onrender.com/generar-stl",
            json=data
        )
        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Error al generar STL remoto.")
        stl_file = f"/mnt/data/{uuid.uuid4()}.stl"
        with open(stl_file, "wb") as f:
            f.write(response.content)
        return FileResponse(stl_file, media_type="application/octet-stream", filename="modelo.stl")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
