
from fastapi import FastAPI, UploadFile, File
from generador_stl_automatico import generar_stl_inteligente
import json

app = FastAPI()

@app.post("/generar-stl")
async def generar_stl_endpoint(file: UploadFile = File(...)):
    contenido = await file.read()
    data = json.loads(contenido)

    vector_paths = data.get("vector_paths")
    altura = data.get("altura_extrusion", 5.0)

    archivo_final = generar_stl_inteligente(vector_paths, altura)

    return {
        "mensaje": "STL generado correctamente.",
        "archivo_stl": archivo_final
    }
