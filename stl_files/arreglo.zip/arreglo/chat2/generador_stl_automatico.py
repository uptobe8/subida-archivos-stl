
import json
import requests
import os
from generador_stl_local import generar_stl_desde_json

def generar_stl_inteligente(vector_paths, altura=5.0, nombre_archivo="modelo_final.stl"):
    payload = {
        "vector_paths": vector_paths,
        "altura_extrusion": altura
    }

    try:
        response = requests.post(
            "https://asistente-de-conversi-n-stl.onrender.com/generar-stl",
            json=payload,
            timeout=10
        )
        if response.status_code == 200:
            with open(nombre_archivo, "wb") as f:
                f.write(response.content)
            print("✅ STL generado desde servidor.")
            return nombre_archivo
        else:
            print("⚠️ Error en el servidor. Código:", response.status_code)
    except Exception as e:
        print("❌ No se pudo contactar el servidor:", e)

    print("🧠 Generando STL en local como respaldo...")
    with open("vector_paths.json", "w") as f:
        json.dump({"vector_paths": vector_paths}, f)

    return generar_stl_desde_json("vector_paths.json", altura, "modelo_final_local.stl")
