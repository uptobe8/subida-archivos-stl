# ❓ FAQ - Preguntas Frecuentes - Asistente UpToBe

---

## 🧩 ¿Qué tipos de archivos puedo subir para convertir en STL?

Puedes subir imágenes en los siguientes formatos:
- `.jpg`
- `.jpeg`
- `.png`
- `.heic`
- `.pdf`
- `.ai`
- `.eps`

**Importante:**  
El contenido debe tener contraste claro (por ejemplo, trazos negros sobre fondo blanco) para garantizar una conversión precisa.

---

## 🧠 ¿Cómo trabaja el asistente UpToBe para convertir imágenes en STL?

El asistente sigue un flujo estricto de alta precisión:
1. Convierte la imagen a blanco y negro binario (preprocesamiento local).
2. Limpia el fondo y el ruido visual mediante técnicas locales (sin IA externa).
3. Vectoriza todos los contornos relevantes, respetando jerarquías internas.
4. Envía los vectores generados a un servidor remoto seguro que realiza la extrusión y generación del archivo STL.
5. Entrega todos los archivos resultantes listos para descarga inmediata.

---

## 📸 ¿La imagen original se modifica?

**No.**  
La imagen original **nunca se modifica**.  
El asistente trabaja en una copia segura del archivo para procesarlo internamente.

---

## 🛠️ ¿El proceso de limpieza utiliza inteligencia artificial externa?

**No.**  
Toda la limpieza se realiza **localmente** mediante detección de contornos jerárquicos con OpenCV.  
No se conecta a servicios de IA externos ni utiliza modelos como Segment Anything.

---

## 📏 ¿Se respetan el tamaño, proporción y resolución originales?

**Sí, siempre.**  
Está estrictamente prohibido:
- Redimensionar (resize)
- Recortar
- Centrar automáticamente
- Ajustar márgenes
- Cambiar la resolución

El asistente procesa las imágenes respetando su escala y tamaño original.

---

## 🧹 ¿Qué pasa si mi imagen tiene ruido, manchas o fondos sucios?

El asistente aplicará una **limpieza profunda automática**:
- Detecta el objeto principal de la imagen.
- Elimina fondos, manchas y residuos.
- Mantiene únicamente los trazos relevantes para vectorización.

---

## 📂 ¿Cómo recibo los archivos generados?

Después de cada fase de procesamiento:
- Se muestra una **vista previa real**.
- Se entrega un **archivo descargable real** (PNG para imágenes o STL para modelos).

Todos los archivos son entregados directamente sin enlaces externos ni vistas simuladas.

---

## 🔄 ¿Puedo detener o corregir el proceso en alguna fase?

Sí.  
Después de cada fase (preprocesado, limpieza, vectorización, generación STL) el asistente:
- Te muestra el resultado.
- Te pregunta si deseas continuar o detener el flujo.

No se avanza automáticamente sin tu confirmación.

---

## 🧩 ¿Qué pasa si ocurre un error durante el proceso?

Si ocurre cualquier fallo técnico:
- El asistente notificará el error exacto.
- Se mostrará el mensaje técnico completo.
- En caso de error grave, propondrá repetir la fase afectada o iniciar un nuevo flujo.

---

## 💬 ¿Cómo puedo contactar soporte si surge un problema?

Para consultas técnicas, incidencias o soporte adicional, puedes contactar a:

- 📧 Email: soporte@uptobe.io

---
