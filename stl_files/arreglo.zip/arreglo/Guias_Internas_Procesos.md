# 🛠️ Guías Internas de Procesos Técnicos - Asistente UpToBe

---

## 📂 Validación de Archivos STL

**Objetivo:**  
Garantizar que el archivo STL generado sea válido y utilizable para impresión 3D o mecanizado CNC.

**Pasos para validar:**

1. **Revisar estructura básica del STL:**
   - Verificar que el STL no esté vacío.
   - Confirmar que contenga vértices y caras (`faces`, `vertices`).

2. **Verificar que el STL esté cerrado (manifold):**
   - El STL debe ser una malla cerrada, sin agujeros.
   - Si hay errores de borde abierto, el modelo puede fallar en impresión.

3. **Validar la normalización de caras:**
   - Las normales de las caras deben apuntar hacia el exterior.
   - Ayuda a los slicers a interpretar correctamente el volumen.

4. **Herramientas recomendadas para validación manual (opcional):**
   - **Meshlab** (gratis).
   - **Microsoft 3D Builder** (Windows).
   - **Blender** (revisión de malla).
   - **Netfabb Online Service** (servicio gratuito de reparación).

---

## 🖼️ Solución de Problemas en el Preprocesamiento de Imágenes

**Problema:**  
- Imagen no se convierte correctamente a binario.
- Resultado visual sucio o distorsionado.

**Posibles causas:**
- Imagen original de baja resolución.
- Contraste insuficiente entre objeto y fondo.

**Soluciones sugeridas:**
- Ajustar brillo/contraste de la imagen antes de subirla.
- Asegurar que el fondo sea blanco o muy claro.
- Utilizar imágenes de al menos 500px de anchura mínima.

---

## 🧹 Solución de Problemas en Limpieza de Imagen

**Problema:**  
- No se detectan contornos.
- Imagen limpia borra elementos importantes (texto, detalles).

**Posibles causas:**
- Imagen demasiado degradada o pixelada.
- Binarización inicial demasiado agresiva.

**Soluciones sugeridas:**
- Volver a cargar la imagen original con mejor resolución.
- Aumentar artificialmente el contraste antes de subir la imagen.
- Evitar imágenes con fondos de color complejo o gradientes.

---

## 🖋️ Solución de Problemas en Vectorización

**Problema:**  
- Vectorización incompleta.
- Contornos mal trazados.

**Posibles causas:**
- Imagen con ruido residual.
- Trazos demasiado finos o discontinuos.

**Soluciones sugeridas:**
- Asegurar que los trazos sean gruesos y continuos.
- Mejorar la limpieza previa (repetir fase de limpieza).
- Revisar que la imagen binaria esté correctamente invertida (objeto en negro sobre fondo blanco).

---

## 🧱 Solución de Problemas en Generación de STL

**Problema:**  
- Error de generación o STL corrupto.

**Posibles causas:**
- Polígonos degenerados (demasiado pequeños o auto-intersecados).
- Fallo interno durante extrusión en el servidor remoto.

**Soluciones sugeridas:**
- Volver a vectorizar contornos con configuración corregida.
- Eliminar residuos en la imagen binaria limpia antes de vectorizar.
- Revisar visualmente el vectorizado antes de la extrusión.
- Verificar que el servidor remoto esté activo y que el payload enviado sea correcto.

---

## 🚨 Reglas de Acción ante Fallos Repetidos

- Nunca intentar forzar la generación STL si la vectorización es defectuosa.
- Siempre repetir el flujo desde la fase anterior en caso de fallo grave.
- En última instancia, solicitar soporte a:

  📧 soporte@uptobe.io
