import json
import trimesh
import shapely.geometry
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from typing import List
import uvicorn

app = FastAPI()

class STLRequest(BaseModel):
    vector_paths: List[List[List[float]]]
    altura_extrusion: float

@app.post("/generar-stl-local")
async def generar_stl_local(data: STLRequest):
    try:
        polygons = []
        for path in data.vector_paths:
            if len(path) >= 3:
                poly = shapely.geometry.Polygon(path)
                if poly.is_valid:
                    polygons.append(poly)
        
        if not polygons:
            raise ValueError("No se encontraron polígonos válidos")

        union_poly = shapely.geometry.MultiPolygon(polygons)
        mesh = trimesh.creation.extrude_polygon(union_poly, height=data.altura_extrusion)

        stl_path = "/mnt/data/modelo_generado_local.stl"
        mesh.export(stl_path)
        return {"stl_path": stl_path}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
