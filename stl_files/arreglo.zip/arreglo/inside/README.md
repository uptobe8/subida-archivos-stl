# 🧠 Asistente de Conversión 2D a STL - UpToBe

Este proyecto convierte imágenes 2D en modelos 3D (archivos STL) listos para impresión 3D o mecanizado CNC, combinando procesamiento de imagen local y generación remota de STL.

---

## 🚀 Funcionalidades

- Preprocesamiento de imágenes local: binarización en blanco y negro.
- Limpieza profunda local mediante detección de contornos jerárquicos.
- Vectorización de contornos local.
- Generación de archivos STL mediante llamada externa a un backend especializado.

---

## 📁 Estructura del Proyecto

- main.py
- Dockerfile
- requirements.txt
- Procfile
- .gitignore
- .gitattributes

---

## ⚙️ Requisitos

```bash
pip install -r requirements.txt
No es necesario instalar triangle localmente.

🧪 Cómo ejecutar localmente
git clone https://github.com/tu_usuario/Asistente-de-conversion-STL.git
cd Asistente-de-conversion-STL
python3 -m venv env && source env/bin/activate
pip install -r requirements.txt
python main.py
Servidor local disponible en:

http://localhost:8000
✨ Endpoints disponibles

Endpoint	Funcionalidad
POST /procesar-imagen	Preprocesar imagen en binario
POST /limpiar	Limpiar imagen detectando contornos
POST /vectorizar-contornos	Vectorizar contornos desde imagen binaria
POST /generar-stl	Generar STL a partir de vectores
📌 Notas técnicas
Todo el procesamiento de imagen (pasos 1 a 3) es estrictamente local.

La generación del STL (paso 4) se realiza mediante backend remoto externo.

Importante:
Para que la generación de STL funcione correctamente, el cliente debe enviar:

Método: POST

URL: https://asistente-de-conversi-n-stl.onrender.com/generar-stl

Header obligatorio:

Content-Type: application/json
Cuerpo (body) en formato JSON:


{
  "vector_paths": [[[x1, y1], [x2, y2], [x3, y3], [x1, y1]], [[x4, y4], [x5, y5], [x6, y6], [x4, y4]]],
  "altura_extrusion": 1.8
}
La respuesta será el archivo STL binario (application/octet-stream).

📂 .gitignore

__pycache__/
*.pyc
*.pyo
*.pyd
.env
.venv
*.env
*.venv
uploads/
