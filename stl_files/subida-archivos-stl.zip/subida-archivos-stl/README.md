# subida-archivos-stl

Repositorio para almacenar archivos STL generados automáticamente y proporcionar enlaces de descarga directa desde GitHub.

## Cómo usar

1. Sube los archivos STL generados a la carpeta `stl_files/`.
2. Haz commit y push al repositorio.
3. Usa el enlace:
   https://github.com/uptobe8/subida-archivos-stl/blob/main/stl_files/<nombre_archivo>.stl?raw=true
   para descarga directa.

## Licencia

MIT
