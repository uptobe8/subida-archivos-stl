# 🧠 Asistente de Conversión 2D a STL - UpToBe

Este proyecto convierte imágenes 2D en modelos 3D (archivos STL) listos para impresión 3D o mecanizado CNC. Realiza todo el procesamiento necesario en el backend, desde imagen hasta STL, con máxima calidad y control.

---

## 🚀 Funcionalidades

- ✅ Preprocesamiento local: conversión de imágenes a blanco y negro binario.
- ✅ Limpieza profunda local basada en contornos jerárquicos (`cv2.RETR_TREE`).
- ✅ Vectorización local y exportación en `.json` + `.png` de vista previa.
- ✅ Generación de archivos STL dentro del propio backend, con extrusión controlada usando `trimesh`.

---

## 📁 Estructura del Proyecto

- `main.py` – Lógica principal y endpoints FastAPI.
- `vector_utils.py` – Conversión de `vector_paths` en mallas 3D STL.
- `requirements.txt`
- `Dockerfile`
- `Procfile`
- `.gitignore`
- `README.md`

---

## ⚙️ Requisitos

```bash
python3 -m venv env
source env/bin/activate
pip install -r requirements.txt
🧪 Cómo ejecutar localmente


uvicorn main:app --reload
Servidor local:
http://localhost:8000

✨ Endpoints disponibles

Endpoint	Funcionalidad
POST /procesar-imagen	Preprocesa la imagen en blanco y negro
POST /limpiar	Limpieza de la imagen binaria
POST /vectorizar-contornos	Vectoriza contornos y exporta JSON + PNG
POST /generar-stl	Genera archivo STL desde los vectores
📌 Notas técnicas
Todo el flujo es ejecutado en el backend desplegado (local o en Render).

No se usa ningún servicio externo para generar el STL.

El STL generado se guarda como archivo real y se entrega al usuario como descarga.

🧼 .gitignore

__pycache__/
*.pyc
*.pyo
*.pyd
.env
.venv
*.env
*.venv
uploads/
*.stl
*.png
*.json
📦 STL de salida
Los archivos STL generados se guardan en la carpeta /mnt/data o stl_outputs/, según configuración.

🛠️ Librerías clave
OpenCV (cv2)

Shapely

Trimesh

FastAPI

NumPy

PIL (Pillow)

🧠 Licencia y mantenimiento
Este proyecto fue desarrollado para uso personal/familiar.
No se destina a fines comerciales. Mantenido por UpToBe.
