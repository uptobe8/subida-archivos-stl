import os
from vector_utils import generar_stl_desde_vector_paths

def test_generacion_stl_simple():
    # Crear un cuadrado básico como vector_path
    square_path = [
        [[0, 0], [0, 10], [10, 10], [10, 0], [0, 0]]
    ]
    
    altura = 5.0

    # Ejecutar la función
    output_path = generar_stl_desde_vector_paths(square_path, altura)

    # Verificar que el archivo STL fue creado
    assert os.path.exists(output_path), "El archivo STL no fue generado"
    
    # Verificar que el archivo no está vacío
    assert os.path.getsize(output_path) > 100, "El archivo STL está vacío o es inválido"

    print("✅ test_generacion_stl_simple pasó correctamente.")
