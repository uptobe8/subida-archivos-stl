import os
import trimesh
import shapely.geometry
import shapely.ops
from shapely.geometry import Polygon, MultiPolygon
import numpy as np
import uuid

OUTPUT_DIR = "stl_outputs"


def generar_stl_desde_vector_paths(vector_paths, altura_extrusion=5.0):
    """
    Genera un archivo STL extruyendo los contornos proporcionados como vector_paths.
    Devuelve la ruta absoluta del archivo STL generado.
    """
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    # Convertir cada path a un polígono válido
    polygons = []
    for path in vector_paths:
        if len(path) < 3:
            continue  # ignorar contornos sin área
        try:
            poly = Polygon(path)
            if poly.is_valid and poly.area > 0:
                polygons.append(poly)
        except Exception as e:
            print(f"Error convirtiendo path a polígono: {e}")

    if not polygons:
        raise ValueError("No se encontraron polígonos válidos para extruir.")

    # Unificar polígonos si hay más de uno
    multi_poly = shapely.ops.unary_union(polygons)

    # Extruir
    try:
        mesh = trimesh.creation.extrude_polygon(multi_poly, height=altura_extrusion)
    except Exception as e:
        raise ValueError(f"Error al extruir la geometría: {str(e)}")

    if not mesh.is_volume:
        raise ValueError("La malla generada no es un sólido válido (no tiene volumen).")

    # Validar y exportar
    filename = f"modelo_{uuid.uuid4().hex}.stl"
    output_path = os.path.join(OUTPUT_DIR, filename)

    try:
        mesh.export(output_path)
    except Exception as e:
        raise ValueError(f"Error al exportar STL: {str(e)}")

    return output_path
