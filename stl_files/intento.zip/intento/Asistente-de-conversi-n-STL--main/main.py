from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
import uvicorn
import cv2
import numpy as np
import tempfile
import requests
from typing import List
import json
import os

app = FastAPI()

SERVER_URL = "https://asistente-de-conversi-n-stl.onrender.com"

# ---------------------------
# Endpoint: Preprocesar imagen
# ---------------------------
@app.post("/procesar-imagen")
async def procesar_imagen(imagen: UploadFile = File(...)):
    """Preprocesar imagen a binario (fondo blanco, trazos negros)."""
    contents = await imagen.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    adaptive_thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        15, 10
    )

    if np.sum(adaptive_thresh == 0) > np.sum(adaptive_thresh == 255):
        adaptive_thresh = cv2.bitwise_not(adaptive_thresh)

    _, temp_path = tempfile.mkstemp(suffix=".png")
    cv2.imwrite(temp_path, adaptive_thresh)

    return StreamingResponse(open(temp_path, "rb"), media_type="image/png")

# ---------------------------
# Endpoint: Limpiar imagen
# ---------------------------
@app.post("/limpiar")
async def limpiar(imagen: UploadFile = File(...)):
    """Limpiar imagen binaria (dibujar contornos, aplicar refinamiento)."""
    contents = await imagen.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)

    # Detectar contornos
    contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Dibujar solo bordes (sin rellenar)
    cleaned_img = np.ones_like(img) * 255  # fondo blanco

    min_area = 100

    for cnt in contours:
        if cv2.contourArea(cnt) > min_area:
            cv2.drawContours(cleaned_img, [cnt], -1, (0,), thickness=2)

    # Refinar contornos: cerrar pequeños huecos y dilatar trazos
    kernel = np.ones((3, 3), np.uint8)
    closed_img = cv2.morphologyEx(cleaned_img, cv2.MORPH_CLOSE, kernel, iterations=2)
    dilated_img = cv2.dilate(closed_img, kernel, iterations=1)

    # Guardar imagen refinada
    _, temp_path = tempfile.mkstemp(suffix=".png")
    cv2.imwrite(temp_path, dilated_img)

    return StreamingResponse(open(temp_path, "rb"), media_type="image/png")

# ---------------------------
# Endpoint: Vectorizar contornos
# ---------------------------
@app.post("/vectorizar-contornos")
async def vectorizar_contornos(ruta_imagen_binaria: str):
    """Extraer contornos de una imagen binaria refinada."""
    img = cv2.imread(ruta_imagen_binaria, cv2.IMREAD_GRAYSCALE)

    contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    vector_paths = []
    for contour in contours:
        contour = contour.squeeze()
        if len(contour.shape) == 1:
            contour = np.expand_dims(contour, axis=0)
        path = contour.tolist()
        if isinstance(path[0], list):  # Asegurarse que sea lista de pares [x,y]
            vector_paths.append(path)

    return {"vector_paths": vector_paths}

# ---------------------------
# Endpoint: Generar STL (ahora compatible con el asistente)
# ---------------------------

from fastapi.responses import FileResponse
from vector_utils import generar_stl_desde_vector_paths
from fastapi import HTTPException
from pydantic import BaseModel
from typing import List

class STLRequest(BaseModel):
    vector_paths: List[List[List[int]]]
    altura_extrusion: float = 5.0

@app.post("/generar-stl")
async def generar_stl_endpoint(request: STLRequest):
    """
    Genera un archivo STL a partir de una lista de vector_paths y altura de extrusión.
    El archivo se guarda y se devuelve como descarga directa.
    Compatible con la estructura esperada por el asistente.
    """
    try:
        vector_paths = request.vector_paths
        altura_extrusion = request.altura_extrusion

        if not vector_paths or not isinstance(vector_paths, list):
            raise HTTPException(
                status_code=422,
                detail="vector_paths no proporcionado o en formato incorrecto."
            )

        output_path = generar_stl_desde_vector_paths(vector_paths, altura_extrusion)

        return FileResponse(
            path=output_path,
            media_type="application/octet-stream",
            filename="modelo_generado.stl"
        )

    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generando STL: {str(e)}")

# ---------------------------
# Ejecutar servidor
# ---------------------------
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
