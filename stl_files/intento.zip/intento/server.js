const express = require('express');
const geojson2stl = require('./');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

app.post('/convertir-a-stl', (req, res) => {
  const { vector_paths, altura_extrusion = 1, output = "modelo.stl", size = 200 } = req.body;

  if (!vector_paths || !Array.isArray(vector_paths)) {
    return res.status(400).json({ error: 'Falta el campo "vector_paths" o su formato no es válido.' });
  }

  const geojson = {
    type: "FeatureCollection",
    features: vector_paths.map((path) => ({
      type: "Feature",
      properties: {},
      geometry: {
        type: "Polygon",
        coordinates: [path]
      }
    }))
  };

  try {
    const stl = geojson2stl(geojson, {
      extrude: altura_extrusion,
      output,
      size
    });

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${output}"`);
    res.send(stl);
  } catch (err) {
    console.error('Error al generar STL:', err.message);
    res.status(500).json({ error: 'No se pudo generar el archivo STL' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor activo en http://localhost:${PORT}`);
});
